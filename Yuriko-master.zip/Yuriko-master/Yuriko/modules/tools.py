__mod_name__ = "Tᴏᴏʟꜱ"

__help__ = """
*Yuriko Info bot*

✗  /sg <reply> - `To check history name`

*Date-time-Weather*

✗  /time - `<country code> Gives information about a timezone.`

✗  /weather - `<city> Get weather info in a particular place.`

✗  /wttr - `<city> Advanced weather module, usage same as /weather`

✗  /wttr - `moon Get the current status of moon`

*Converts*

✗  /encrypt - `Encrypts The Given Text`

✗  /decrypt - `Decrypts Previously Ecrypted Text`

✗  /zip - `reply to a telegram file to compress it in .zip format`

✗  /unzip - `reply to a telegram file to decompress it from the .zip format`

*Random API*

✗  /ptl *or* /asupan - `get random video from Instagram timeline`

✗  /chika - `get random video from chikakiku`

✗  /wibu - `get random short anime video or photos`

✗  /truth - `challenge`

✗  /dare - `challenge`

*Link To File:*

✗  /up - `reply to a direct download link to upload it to telegram as files`
 
 *File To Link:*

✗  /transfersh - `reply to a telegram file to upload it on transfersh and get direct download link`

✗  /tmpninja - `reply to a telegram file to upload it on tmpninja and get direct download link`

 *File Or Text To Telegraph:*

✗  /tgm - `Get Telegraph Link Of Replied Media`

✗  /tgt - `Get Telegraph Link of Replied Text`

 *Tagger*

✗  /tagall - `for tag everyone at least 100 member first.`

*✗ Pᴏᴡᴇʀᴇᴅ 💕 Bʏ: BᴏᴛDᴜɴɪʏᴀ!*
"""
