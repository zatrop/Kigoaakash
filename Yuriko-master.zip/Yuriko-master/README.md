#Note this is old repo of KIGO now time to update 🙂. 

<h1 align="center"><b> ⚡ UPDATING ⚡ </b></h1>

<h4 align="center">A Powerful, Smart And Simple Group Manager <br> ... Written with AioGram , Pyrogram and Telethon...</h4>
<p align='center'>
  <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-1f425f.svg?style=flat-square&logo=python&color=blue" /> </a>
  <a href="https://github.com/AMANTYA1/YURIKO_2.0/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=flat-square" /> </a>
</p>

<p align="center"><a href="https://t.me/KIGO_OMFOBOt"><img src="(https://telegra.ph/file/e641d3dd2ccdce6a3d934.jpg)" width="400"></a></p>

## Available on Telegram as this is repo private [@KIGO](https://t.me/KIGO_OMFOBOt)

## This is Yuriko  [@Yuriko](https://t.me/Yurikobot)

# ❤️ Support
<a href="https://t.me/BotDuniyaXd"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
<a href="https://t.me/godzilla_chatting"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>


## ✨ Heroku Deploy ✨
The easiest way to deploy this Bot is via Heroku.

<p align="left"><a href="https://heroku.com/deploy?template=https://github.com/AMANTYA1/YURIKO_2.0"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
```

### 🧪 Get STRING_SESSION from below (Easy method) :
[![GenerateString](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://t.me/TELETHON_PYROGRAM_STRINGBOT) ``Pyrogram``
